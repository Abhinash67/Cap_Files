package com.capgemini.com.gxmatcher;

import com.capgemini.com.gxmatcher.constants.MessageDestination;
import com.capgemini.com.gxmatcher.main.GXMatcher;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GXMatcherNegativeTest extends TestCase{
	
	private GXMatcher negativeMatcher = null;
	/**
	 * Create the test case
	 * 
	 * @param testName
	 *    name of the test case
	 */
	public GXMatcherNegativeTest(String testName) {
		super("testGXMatcherNegative");
		PropertiesUtil.initialize("local");
		String filePath1 = getClass().getClassLoader().getResource("6235753592_111_RESPONSE-neg.xml").getFile();
		String filePath2 = getClass().getClassLoader().getResource("6801849253_111_RESPONSE-neg.xml").getFile();
		negativeMatcher = new GXMatcher(MessageDestination.MD1, filePath1, filePath2);
	}
	
	public static Test suite() {
		return new TestSuite(GXMatcherNegativeTest.class);
	}
	
	public void testGXMatcherNegative() {
		assertFalse(negativeMatcher.match());
	}
}
