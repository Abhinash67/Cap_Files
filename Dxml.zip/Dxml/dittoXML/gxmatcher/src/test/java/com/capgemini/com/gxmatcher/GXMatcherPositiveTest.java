package com.capgemini.com.gxmatcher;

import com.capgemini.com.gxmatcher.constants.MessageDestination;
import com.capgemini.com.gxmatcher.main.GXMatcher;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

public class GXMatcherPositiveTest extends TestCase {
private GXMatcher positiveMatcher = null;

	/**
	 * Create the test case
	 * 
	 * @param testName
	 *    name of the test case
	 */
	public GXMatcherPositiveTest(String testName) {
		super("testGXMatcherPositive");
		PropertiesUtil.initialize("local");
		String filePath1 = getClass().getClassLoader().getResource("6235753592_111_RESPONSE.xml").getFile();
		String filePath2 = getClass().getClassLoader().getResource("6801849253_111_RESPONSE.xml").getFile();
		positiveMatcher = new GXMatcher(MessageDestination.MD1, filePath1, filePath2);
	}
	
	public static Test suite() {
		return new TestSuite(GXMatcherPositiveTest.class);
	}
	
	public void testGXMatcherPositive() {
		assertTrue(positiveMatcher.match());
	}
}

