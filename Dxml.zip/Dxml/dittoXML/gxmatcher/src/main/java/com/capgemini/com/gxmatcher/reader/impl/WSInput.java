package com.capgemini.com.gxmatcher.reader.impl;

import java.net.MalformedURLException;
import java.net.URL;

import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.constants.Constants;
import com.capgemini.com.gxmatcher.payload.PayloadInfo;
import com.capgemini.com.gxmatcher.reader.GXInput;
import com.guidewire.pc.ws.com.capgemini.dittoxml.retrievepayloadapi.RetrievePayloadAPI;
import com.guidewire.pc.ws.com.capgemini.dittoxml.retrievepayloadrequest.RetrievePayloadRequest;
import com.guidewire.pc.ws.com.capgemini.dittoxml.retrievepayloadresponse.RetrievePayloadResponse;

public class WSInput extends GXInput{
	final static Logger logger = Logger.getLogger(WSInput.class);
	private URL url = null;
	
	public WSInput(PayloadInfo payloadInfo) {
		super(payloadInfo);
		try {
			this.url =  new URL(payloadInfo.getUrl());
		} catch (MalformedURLException e) {
			logger.error("Error while generating URL_ " + payloadInfo.getUrl(),e);
		}
	}
	
	@Override
	public String getFileName() {
		String filePath = null;
		if(logger.isDebugEnabled()) {
			logger.debug("Calling Web Services for "+ this.payloadInfo.toString());
		}
		
		filePath = invokeWebService(payloadInfo);
		
		if(filePath == null) {
			if(logger.isDebugEnabled()) {
				logger.debug("Payload not found");
			}
		}
		return filePath;
	}
	
	private String invokeWebService(PayloadInfo payloadInfo) {
		String filePath = null;
		
		//map the input
		RetrievePayloadRequest payloadRequest = createPayloadRequest(payloadInfo);
		RetrievePayloadResponse payloadResponse =null;
		
		//call the webservice
		try {
			RetrievePayloadAPI api = new RetrievePayloadAPI(this.url);
			payloadResponse = api.getRetrievePayloadAPISoap11Port()
					.retrievePayload(payloadRequest);
			if(payloadResponse!= null) {
				if(payloadResponse.getStatus().equalsIgnoreCase(Constants.SUCCESS)) {
					filePath = payloadResponse.getFileName();
				}
			}
		}catch (Exception e) {
			logger.error("Error while calling web services...", e);
		}
		
		return filePath;
	}
	
	private RetrievePayloadRequest createPayloadRequest(PayloadInfo payloadInfo) {
		RetrievePayloadRequest request = new RetrievePayloadRequest();
		request.setAccountNumber(payloadInfo.getAccountNumber());
		request.setPolicyNumber(payloadInfo.getPolicyNumber());
		request.setCustomerName(payloadInfo.getCustomerName());
		request.setTransactionID(payloadInfo.getTransactionID());
		request.setEventName(payloadInfo.getEventName());
		request.setServiceID(payloadInfo.getServiceID());
		request.setPayloadType(payloadInfo.getPayloadType());
		return request;
	}
}
