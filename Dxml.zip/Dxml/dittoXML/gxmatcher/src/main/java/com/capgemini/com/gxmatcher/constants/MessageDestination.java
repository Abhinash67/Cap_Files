package com.capgemini.com.gxmatcher.constants;

public enum MessageDestination {
	MD1("ODS", "15");

	private String destinationName;
	private String destinationID;

	private MessageDestination(String destinationName, String destinationID) {
		this.destinationName = destinationName;
		this.destinationID = destinationID;
	}

	public String getDestinationName() {
		return destinationName;
	}

	public String getDestinationID() {
		return destinationID;
	}

}
