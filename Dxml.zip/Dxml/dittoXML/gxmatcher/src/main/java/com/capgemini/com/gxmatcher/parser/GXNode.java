package com.capgemini.com.gxmatcher.parser;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "RootNode")
public class GXNode implements Comparable<GXNode> {

	private String elementName;
	private String value;
	private boolean missingNode;

	private String key;
	private String parentKey;
	private String elementFullKey;
	private GXNode parent = null;
	private List<GXNode> children = new ArrayList<GXNode>();

	public GXNode() {
	}

	public GXNode(String elementName, GXNode parent) {
		super();
		this.elementName = elementName;
		this.parent = parent;
	}

	@XmlElement
	public String getElementName() {
		return elementName;
	}

	public void setElementName(String elementName) {
		this.elementName = elementName;
	}

	@XmlElement
	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public GXNode getParent() {
		return parent;
	}

	public void setParent(GXNode parent) {
		this.parent = parent;
	}

	@XmlElement(name = "Node")
	public List<GXNode> getChildren() {
		return children;
	}

	public void addChild(GXNode node) {
		this.children.add(node);
	}

	public boolean isLeaf() {
		return this.children.size() == 0;
	}
	
	public boolean isMissingNode() {
		return missingNode;
	}

	public void setMissingNode(boolean missingNode) {
		this.missingNode = missingNode;
	}

	@Override
	public String toString() {
		if(this.key != null) {
			return key;
		}
		String value = "";
		if (this.isLeaf()) {
			value = this.getElementName() + "~" + this.getValue();
		} else {
			Collections.sort(this.children);
			List<String> childStrings = new ArrayList<String>();
			for (GXNode child : this.children) {
				childStrings.add(child.toString());
			}
			value = String.join("|", childStrings);
		}
		this.key = value;
		return value;
	}

	@Override
	public int compareTo(GXNode o) {
		return this.toString().compareTo(o.toString());
	}
	
	//New changes
	public void reverseLookUp(Map<String, GXNode> map) {
		map.put(this.getElementFullKey(), this);
		if (!this.isLeaf()) {
			for (GXNode child : this.children) {
				child.reverseLookUp(map);
			}
		}
	}
	
	
	public String getElementFullKey() {
		if(this.elementFullKey != null) {
			return this.elementFullKey;
		}
		String value = this.getParentKey(); 
		if(this.isLeaf()) {
			value = value +this.getElementName() +"~"+this.getValue();	
		}
		this.elementFullKey = value;
		return value;
	}
	
	private String getParentKey() {
		if(this.parentKey !=null) {
			return this.parentKey;
		}
		String value = "";
		if(this.parent != null) {
			value = this.parent.getParentKey()+"\\";
		}
		if(!this.isLeaf()) {
			value = value +this.getElementName() +this.getChildString();	
		}
		this.parentKey = value;
		return value;
	}
	

	private String getChildString() {
		List<String> childStrings = new ArrayList<String>();
		for (GXNode child : this.children) {
			if(child.isLeaf()) {
				childStrings.add(child.getElementName() +"~"+child.getValue());
			}
		}
		return "["+String.join("|", childStrings)+"]";
	}
	
	
}
