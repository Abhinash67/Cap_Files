package com.capgemini.com.gxmatcher.app;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternScript {

	public static void main(String[] args) {
		String xmlTag = "SubmissionDate";
		String pattern = "<(.*)(:?)"+xmlTag+">(.*)</(.*)(:?)"+xmlTag+">";
		String line = "<SubmissionDate>2016-06-27T13:35:28.123-04:00</SubmissionDate>";
		
		Pattern r = Pattern.compile(pattern);
		
			//Now create matcher object.
			Matcher m = r.matcher(line);
			
			if (m.find()) {
				System.out.println("Found value: " + m.group(0) );
				System.out.println("Found value: " + m.group(1) );
				System.out.println("Found value: " + m.group(2) );
				System.out.println("Found value: " + m.group(3) );
				System.out.println("Found value: " + m.group(4) );
				System.out.println("Found value: " + m.group(5) );
			}
			else {
				System.out.println("NO MATCH");
			}

	}

}
