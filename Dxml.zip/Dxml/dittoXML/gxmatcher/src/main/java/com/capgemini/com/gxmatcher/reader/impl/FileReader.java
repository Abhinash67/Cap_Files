package com.capgemini.com.gxmatcher.reader.impl;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.reader.GXReader;

public class FileReader extends GXReader{
	
	final static Logger logger = Logger.getLogger(FileReader.class);
	
	private String filePath;
	
	public FileReader(String filePath) {
		super();
		this.filePath = filePath;
	}
	
	
	@SuppressWarnings("deprecation")
	public String readXML() {
		if(logger.isDebugEnabled()) {
			logger.debug("Reading XML file from " + this.filePath+"....");
		}
		File file = new File(this.filePath);
		try {
			return FileUtils.readFileToString(file);
		}catch (IOException e) {
			logger.error("Error while reading XML from "+this.filePath+"...", e);
		}
		return null;
	}
	

}
