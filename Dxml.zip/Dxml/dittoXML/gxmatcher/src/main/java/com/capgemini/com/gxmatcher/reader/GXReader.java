package com.capgemini.com.gxmatcher.reader;

public abstract class GXReader {

	private String xml;

	public abstract String readXML();

	public String getXml() {
		return xml;
	}

}
