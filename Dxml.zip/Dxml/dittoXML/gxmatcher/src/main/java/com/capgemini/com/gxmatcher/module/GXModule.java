package com.capgemini.com.gxmatcher.module;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.cleanser.GXCleanser;
import com.capgemini.com.gxmatcher.constants.MessageDestination;
import com.capgemini.com.gxmatcher.parser.GXNode;
import com.capgemini.com.gxmatcher.parser.GXParser;
import com.capgemini.com.gxmatcher.reader.GXReader;
import com.capgemini.com.gxmatcher.util.HashingUtil;
import com.capgemini.com.gxmatcher.util.XMLUtil;

public class GXModule {

	final static Logger logger = Logger.getLogger(GXModule.class);
	private MessageDestination messageDestination;
	private GXReader reader;
	private GXCleanser cleanser;
	private GXParser parser;
	private GXNode rootNode;

	public GXModule(MessageDestination messageDestination, GXReader reader, GXCleanser cleanser, GXParser parser) {
		super();
		this.messageDestination = messageDestination;
		this.reader = reader;
		this.cleanser = cleanser;
		this.parser = parser;
	}

	/**
	 * Computes a checksum for payload
	 */
	public String getChecksum() {
		if (logger.isInfoEnabled()) {
			logger.info("Transforming XML....");
		}
		String xml = transformGX();
		if (logger.isInfoEnabled()) {
			logger.info("Transformation complete....");
		}
		if (StringUtils.isBlank(xml)) {
			return null;
		}
		return computeChecksum(xml);
	}

	/**
	 * Reads, cleans and sorts the gx payload
	 * 
	 * @return
	 */
	private String transformGX() {
		String xml = this.reader.readXML();
		if (StringUtils.isBlank(xml)) {
			return null;
		}

		String cleansedXML = this.cleanser.cleanse(xml);
		if (StringUtils.isBlank(cleansedXML)) {
			return null;
		}

		this.rootNode = this.parser.parseXML(cleansedXML);

		if (rootNode == null) {
			return null;
		}

		if (logger.isInfoEnabled()) {
			logger.info("Sorting XML....");
		}
		String sortedXML = rootNode.toString();
		if (logger.isInfoEnabled()) {
			logger.trace(sortedXML);
		}
		return sortedXML;
	}

	/**
	 * Computes the checksum of the given string
	 * 
	 * @param xml
	 * @return
	 */
	private String computeChecksum(String xml) {
		if (logger.isInfoEnabled()) {
			logger.info("Generating checksum....");
		}
		String checksum = HashingUtil.generateMD5(xml);
		return checksum;
	}

	/**
	 * Writes the sorted XML to the file system
	 * 
	 * @param fileName
	 */
	public void writeFullSortedXML(String fileName) {
		XMLUtil.marshal(this.rootNode, fileName);
	}
	
	public Map<String, GXNode> getReverseLookupMap(){
		Map<String, GXNode> reverseLookUpMap = new HashMap<String,GXNode>();
		this.rootNode.reverseLookUp(reverseLookUpMap);
		return reverseLookUpMap;
	}
}
