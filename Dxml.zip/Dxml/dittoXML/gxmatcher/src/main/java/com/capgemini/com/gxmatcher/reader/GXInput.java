package com.capgemini.com.gxmatcher.reader;

import com.capgemini.com.gxmatcher.payload.PayloadInfo;

public abstract class GXInput {

	protected PayloadInfo payloadInfo;

	public GXInput(PayloadInfo payloadInfo) {
		super();
		this.payloadInfo = payloadInfo;
	}

	public abstract String getFileName();

}
