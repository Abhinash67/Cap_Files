package com.capgemini.com.gxmatcher.app;

import com.capgemini.com.gxmatcher.constants.MessageDestination;
import com.capgemini.com.gxmatcher.main.GXMatcher;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;

public class Script {

	public static void main(String[] args) {
		PropertiesUtil.initialize("local");
		String filePath1= "C:\\Personal\\Tools\\testspace\\dittoXML\\samples\\big1.xml";
		String filePath2= "C:\\Personal\\Tools\\testspace\\dittoXML\\samples\\big2.xml";
		GXMatcher matcher = new GXMatcher (MessageDestination.MD1, filePath1, filePath2);
		boolean match = matcher.match();
		System.out.println("Result " + match);
	}

}
