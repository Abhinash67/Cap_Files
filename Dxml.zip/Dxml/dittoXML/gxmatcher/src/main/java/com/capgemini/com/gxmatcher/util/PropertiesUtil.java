package com.capgemini.com.gxmatcher.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

public class PropertiesUtil {

	final static Logger logger = Logger.getLogger(Properties.class);

	private static final String PROPERTY_FILENAME = "gxmatcher-env.properties";
	private static final String WSDL_URL = "wsdl.url";
	private static final String XML_FILE_PATH = "xml.file.path";
	private static final String EXCEL_FILE_PATH = "excel.file.path";
	private static final String XML_MISMATCH_FILE_PATH = "xml.mismatch.file.path";
	private static final String RESULT_FILE_PATH = "result.file.path";
	private static final String TERMINATION_WAIT_TIME = "termination.wait.time";

	private String env = "local";

	private Properties properties = null;
	private static PropertiesUtil propertyUtil = null;

	private PropertiesUtil(String envName) {
		if (!StringUtils.isEmpty(envName)) {
			this.env = envName;
		}
		String fileName = PROPERTY_FILENAME.replace("env", env);
		this.properties = new Properties();
		InputStream input = getClass().getClassLoader().getSystemResourceAsStream(fileName);

		if (input == null) {
			logger.error("Error while loading input stream of properties file " + fileName + "....");
		}
		try {
			this.properties.load(input);
		} catch (IOException e) {
			logger.error("error while loading properties file " + fileName + "....");
		}
	}

	public static void initialize(String envName) {
		propertyUtil = new PropertiesUtil(envName);
	}

	public static PropertiesUtil getInstance() {
		return propertyUtil;
	}

	public String getXMLFilePath() {
		return propertyUtil.properties.getProperty(XML_FILE_PATH);
	}

	public String getWSDLUrl() {
		return propertyUtil.properties.getProperty(WSDL_URL);
	}

	public String getExcelFilePath() {
		return propertyUtil.properties.getProperty(EXCEL_FILE_PATH);
	}

	public void setExcelFilePath(String excelFilePath) {
		propertyUtil.properties.setProperty(EXCEL_FILE_PATH, excelFilePath);
	}

	public String getMismatchXMLFilePath() {
		return propertyUtil.properties.getProperty(XML_MISMATCH_FILE_PATH);
	}

	public String getResultFilePath() {
		return propertyUtil.properties.getProperty(RESULT_FILE_PATH);
	}

	public int getTerminationWaitTime() {
		return Integer.parseInt(propertyUtil.properties.getProperty(TERMINATION_WAIT_TIME));
	}
}