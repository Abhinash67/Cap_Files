package com.capgemini.com.gxmatcher.util;

import java.security.MessageDigest;

public class HashingUtil {

	public static String generateMD5(String message) {
		return hashString(message, "MD5");
	}

	public static String generateSHA1(String message) {
		return hashString(message, "SHA-1");
	}

	public static String generateSHA256(String message) {
		return hashString(message, "SHA-256");
	}

	private static String convertBytearrayToHexString(byte[] arrayBytes) {
		StringBuffer stringBuffer = new StringBuffer();
		for (int i = 0; i < arrayBytes.length; i++) {
			stringBuffer.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1));
		}
		return stringBuffer.toString();
	}

	private static String hashString(String message, String algorithm) {
		try {
			MessageDigest digest = MessageDigest.getInstance(algorithm);
			byte[] hashedBytes = digest.digest(message.getBytes("UTF-8"));

			return convertBytearrayToHexString(hashedBytes);
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return null;
	}
}
