package com.capgemini.com.gxmatcher.payload;

public class PayloadPair {

	private PayloadInfo payloadInfo1;
	private PayloadInfo payloadInfo2;
	private boolean match;
	private String recordNumber;

	public PayloadPair(String recordNumber, PayloadInfo payloadInfo1, PayloadInfo payloadInfo2) {
		super();
		this.recordNumber = recordNumber;
		this.payloadInfo1 = payloadInfo1;
		this.payloadInfo2 = payloadInfo2;
	}

	public PayloadInfo getPayloadInfo1() {
		return payloadInfo1;
	}

	public PayloadInfo getPayloadInfo2() {
		return payloadInfo2;
	}
	
	public String getRecordNumber() {
		return recordNumber;
	}

	public boolean isMatch() {
		return match;
	}

	public void setMatch(boolean match) {
		this.match = match;
	}

}
