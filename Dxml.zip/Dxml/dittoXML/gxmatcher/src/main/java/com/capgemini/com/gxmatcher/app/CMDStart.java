package com.capgemini.com.gxmatcher.app;
import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.main.DittoXML;
import com.capgemini.com.gxmatcher.reader.impl.ExcelPayloadReader;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;
import com.capgemini.com.gxmatcher.writer.impl.JSONResultWriter;

public class CMDStart {

	final static Logger logger = Logger.getLogger(CMDStart.class);
	
	public static void main(String[] args) {
		String env = "local";
		String excelFile = null;
		if(args.length > 0) {
			for(String arg : args) {
				if(arg.contains("env")) {
					env = arg.split("=")[1];
				}
				if(arg.contains("input")) {
					excelFile = arg.split("=")[1];
				}
			}
		}
		
		PropertiesUtil.initialize(env);
		if(excelFile != null) {
			PropertiesUtil.getInstance().setExcelFilePath(excelFile);
		}
		
		DittoXML dittoXML = new DittoXML(new ExcelPayloadReader(), new JSONResultWriter());
		dittoXML.start();
	}
}
