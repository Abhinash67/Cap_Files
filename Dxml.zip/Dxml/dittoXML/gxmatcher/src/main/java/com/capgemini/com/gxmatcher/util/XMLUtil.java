package com.capgemini.com.gxmatcher.util;

import java.io.File;
import java.io.IOException;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.capgemini.com.gxmatcher.constants.Constants;
import com.capgemini.com.gxmatcher.parser.GXNode;

public class XMLUtil {
	final static Logger logger = Logger.getLogger(XMLUtil.class);

	/**
	 * Marshals  the GXNode to file using JAXB
	 * @param node
	 * @param fileName
	 */
	public static void jaxbMarshal(GXNode node, String fileName) {
		try {
			JAXBContext context = JAXBContext.newInstance(node.getClass());
			Marshaller marshaller = context.createMarshaller();
			marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
			marshaller.setListener(new Marshaller.Listener() {

				private GXNode parent;

				@Override
				public void afterMarshal(Object object) {
					if (object instanceof GXNode) {
						GXNode n = (GXNode) object;
						n.setParent(parent);
						parent = null;
					}
				}

				@Override
				public void beforeMarshal(Object object) {
					if (object instanceof GXNode) {
						GXNode n = (GXNode) object;
						parent = n.getParent();
						n.setParent(null);
					}
				}
			});

			File file = createFile(fileName);
			marshaller.marshal(node, file);
		} catch (Exception ex) {
			logger.error("Error while marshalling XML", ex);
		}
	}
	
	/**
	 * Marshals  the GXNode to file
	 * @param node
	 * @param fileName
	 */
	public static void marshal(GXNode node, String fileName) {
		try {
		File file = createFile(fileName);
		String xml = marshalXMLString(node);
		xml = prettyPrint(xml);
		FileUtils.write(file, xml);
		} catch (Exception e) {
			logger.error("Error while marshalling XML", e);
		}
		
	}
	
	/**
	 * Marshals the nodes recursively 
	 * @param node
	 * @return
	 */
	private static String marshalXMLString(GXNode node) {
		String xml = "<" + node.getElementName() + ">";
		if (!node.isLeaf()) {
			for (GXNode child : node.getChildren()) {
				if(child.isMissingNode()) {
					xml = xml + Constants.MISSING_NODE;	
				}
				xml = xml + marshalXMLString(child);
			}
		} else {
			xml = xml + node.getValue();
		}
		xml = xml + "</" + node.getElementName() + ">";
		return xml;
	}
	
	/**
	 * Creates the file with the given name
	 * @param fileName
	 * @return
	 */
	private static File createFile(String fileName) {
		File file = new File(fileName);
		file.getParentFile().mkdirs();
		return file;
	}
	
	/**
	 * Pretty Prints the XML with line breaks and indentation
	 * @param unformattedXML
	 * @return
	 */
	public static String prettyPrint(String unformattedXML) {
		String xml = null;
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(IOUtils.toInputStream(unformattedXML));

			Transformer tform = TransformerFactory.newInstance().newTransformer();
			tform.setOutputProperty(OutputKeys.INDENT, "yes");
			tform.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			StreamResult result = new StreamResult(new StringWriter());
			tform.transform(new DOMSource(document), result);

			xml = result.getWriter().toString();
		} catch (Exception e) {
			logger.error("Error while pretty printing XML", e);
		}
		return xml;
	}
}
