package com.capgemini.com.gxmatcher.util;

import java.text.SimpleDateFormat;
import java.util.Date;

public class GXMatcherUtil {
	public static final String CONSTANT_TIMESTAMP = getTimeStamp();

	public static String getTimeStamp() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		Date date = new Date();
		return sdf.format(date);
	}

}
