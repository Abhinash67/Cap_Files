package com.capgemini.com.gxmatcher.reader;

import java.util.List;

import com.capgemini.com.gxmatcher.payload.PayloadPair;

public interface PayloadInputReader {
	
	public List<PayloadPair> generatePayloadInfos();

}
