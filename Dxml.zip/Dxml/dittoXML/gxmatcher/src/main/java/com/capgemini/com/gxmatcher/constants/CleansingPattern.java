package com.capgemini.com.gxmatcher.constants;

import com.capgemini.com.gxmatcher.util.PatternUtil;;

public enum CleansingPattern {
	TRANSACTIONID(PatternUtil.getXMLTagPattern("TransactionID"), Constants.EMPTY_STRING),
	TransactionId(PatternUtil.getXMLTagPattern("TransactionId"), Constants.EMPTY_STRING),
	RESPONSETIME(PatternUtil.getXMLTagPattern("ResponseTime"), Constants.EMPTY_STRING),
	PUBLICID(PatternUtil.getXMLTagPattern("PublicID"), Constants.EMPTY_STRING),
	FixedId(PatternUtil.getXMLTagPattern("FixedId"), Constants.EMPTY_STRING),
	Value(PatternUtil.getXMLTagPattern("Value"), Constants.EMPTY_STRING),
	CreateTime(PatternUtil.getXMLTagPattern("CreateTime"), Constants.EMPTY_STRING),
	AccountCreationDate_Ext(PatternUtil.getXMLTagPattern("AccountCreationDate_Ext"), Constants.EMPTY_STRING),
	SenderRefId(PatternUtil.getXMLTagPattern("SenderRefId"), Constants.EMPTY_STRING);
	
	private String pattern;
	private String replacementString;

	private CleansingPattern(String pattern, String replacementString) {
		this.pattern = pattern;
		this.replacementString = replacementString;
	}

	public String getPattern() {
		return pattern;
	}

	public String getReplacementString() {
		return replacementString;
	}

}
