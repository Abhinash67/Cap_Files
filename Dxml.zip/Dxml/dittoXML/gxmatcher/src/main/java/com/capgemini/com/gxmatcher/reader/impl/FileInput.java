package com.capgemini.com.gxmatcher.reader.impl;

import com.capgemini.com.gxmatcher.payload.PayloadInfo;
import com.capgemini.com.gxmatcher.reader.GXInput;

public class FileInput extends GXInput {

	public FileInput(PayloadInfo payloadInfo) {
		super(payloadInfo);
	}

	@Override
	public String getFileName() {
		return this.payloadInfo.getFileName();
	}

}
