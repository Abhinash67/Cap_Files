package com.capgemini.com.gxmatcher.validator.impl;

import com.capgemini.com.gxmatcher.validator.GXValidator;

public class DefaultValidator extends GXValidator {

	@Override
	public boolean validate(String xml) {
		boolean isValid = false;
		return isValid;
	}

}
