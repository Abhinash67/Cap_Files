package com.capgemini.com.gxmatcher.reader.impl;

import com.capgemini.com.gxmatcher.payload.PayloadPair;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.capgemini.com.gxmatcher.payload.PayloadInfo;

import com.capgemini.com.gxmatcher.reader.PayloadInputReader;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;

public class ExcelPayloadReader implements PayloadInputReader {

	final static Logger logger = Logger.getLogger(ExcelPayloadReader.class);

	private XSSFSheet sheet;

	public ExcelPayloadReader() {
		String filePath = PropertiesUtil.getInstance().getExcelFilePath();
		try {
			if(logger.isDebugEnabled()) {
				logger.debug("Read Excel file from " + filePath);
			}
			XSSFWorkbook wf = new XSSFWorkbook(filePath);
			sheet = wf.getSheetAt(0);
		} catch (IOException e) {
			logger.error("Error while reading excel " + filePath, e);
		}
	}

	@Override
	public List<PayloadPair> generatePayloadInfos() {
		// GW8

		String readType1 = sheet.getRow(1).getCell(1).getStringCellValue();
		String url1 = sheet.getRow(1).getCell(2).getStringCellValue();

		// GW10

		String readType2 = sheet.getRow(2).getCell(1).getStringCellValue();
		String url2 = sheet.getRow(2).getCell(2).getStringCellValue();

		List<PayloadPair> infos = new ArrayList<PayloadPair>();

		Iterator<Row> itr = sheet.rowIterator();
		while (itr.hasNext()) {
			Row row = itr.next();
			if (row.getCell(0).getCellType() != CellType.NUMERIC) {
				continue;
			}

			String filePath = null;
			String url = null;
			

			if (readType1.equalsIgnoreCase("File")) {
				filePath = url1 + "/" + row.getCell(8).getStringCellValue();
			} else if (readType1.equalsIgnoreCase("Server")) {
				url = url1;
			}

			DataFormatter df = new DataFormatter();
			
			String recordNumber = df.formatCellValue(row.getCell(0));
			
			PayloadInfo payloadInfo1 = new PayloadInfo(df.formatCellValue(row.getCell(1)),
					df.formatCellValue(row.getCell(2)),
					df.formatCellValue(row.getCell(3)),
					df.formatCellValue(row.getCell(4)),
					df.formatCellValue(row.getCell(5)),
					df.formatCellValue(row.getCell(6)),
					df.formatCellValue(row.getCell(7)),
					filePath, url);

			if (readType2.equalsIgnoreCase("File")) {
				filePath = url2 + "/" + row.getCell(16).getStringCellValue();
			} else if (readType2.equalsIgnoreCase("Server")) {
				url = url2;
			}

			PayloadInfo payloadInfo2 = new PayloadInfo(df.formatCellValue(row.getCell(9)),
					df.formatCellValue(row.getCell(10)),
					df.formatCellValue(row.getCell(11)),
					df.formatCellValue(row.getCell(12)),
					df.formatCellValue(row.getCell(13)),
					df.formatCellValue(row.getCell(14)),
					df.formatCellValue(row.getCell(15)),
					filePath, url);
			
			infos.add(new PayloadPair(recordNumber,
					payloadInfo1, payloadInfo2));
		}
		if(logger.isDebugEnabled()) {
			logger.debug("Number of records to be compared  " + infos.size());
		}
		return infos;
	}

}
