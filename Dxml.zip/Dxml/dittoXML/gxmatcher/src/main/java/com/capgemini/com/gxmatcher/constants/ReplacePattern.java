package com.capgemini.com.gxmatcher.constants;

import com.capgemini.com.gxmatcher.util.PatternUtil;;

public enum ReplacePattern {

	ACCOUNTNUMBER(PatternUtil.getXMLTagPattern("AccountNumber")),
	EXTERNALKEY_EXT(PatternUtil.getXMLTagPattern("ExternalKey_Ext")),
	ENTERPRISEPOLICYID_EXT(PatternUtil.getXMLTagPattern("EnterprisepolicyId_Ext")),
	POLICYNUMBER(PatternUtil.getXMLTagPattern("PolicyNumber")),
	PolicyNumber_Ext(PatternUtil.getXMLTagPattern("PolicyNumber_Ext")),
	JOBNUMBER(PatternUtil.getXMLTagPattern("JobNumber")),
	BillingAccountNumber(PatternUtil.getXMLTagPattern("BillingAccountNumber")),
	BillingNumber_Ext(PatternUtil.getXMLTagPattern("BillingNumber_Ext")),
	PrimaryInsuredName(PatternUtil.getXMLTagPattern("PrimaryInsuredName")),
	CloseDate(PatternUtil.getXMLTagPattern("CloseDate"));

	private String pattern;

	private ReplacePattern(String pattern) {
		this.pattern = pattern;
	}

	public String getPattern() {
		return pattern;
	}

}
