package com.capgemini.com.gxmatcher.parser.impl;

import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.capgemini.com.gxmatcher.namespaces.NameSpaceHandler;
import com.capgemini.com.gxmatcher.parser.GXNode;
import com.capgemini.com.gxmatcher.parser.GXParser;

public class GXSAXParser extends DefaultHandler implements GXParser {

	final static Logger logger = Logger.getLogger(GXSAXParser.class);

	private GXNode activeElement = null;
	private NameSpaceHandler nameSpaceHandler;

	public GXSAXParser(NameSpaceHandler nameSpaceHandler) {
		super();
		this.nameSpaceHandler = nameSpaceHandler;
	}

	@Override
	public void startPrefixMapping(String prefix, String uri) throws SAXException {
		this.nameSpaceHandler.addNameSpace(uri);
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		// remove Name Spaces
		String eleName = replaceNameSpace(uri, localName);
		// create Child
		GXNode child = new GXNode(eleName, activeElement);
		if (activeElement != null) {
			activeElement.addChild(child);
		}
		activeElement = child;
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		if (activeElement.getParent() != null) {
			activeElement = activeElement.getParent();
		}
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		String value = new String(ch, start, length);
		if (!StringUtils.isBlank(value)) {
			activeElement.setValue(value);
		}
	}

	public GXNode getRootElement() {
		return activeElement;
	}

	@SuppressWarnings("deprecation")
	@Override
	public GXNode parseXML(String xml) {
		SAXParserFactory factory = SAXParserFactory.newInstance();
		factory.setNamespaceAware(true);
		try {
			SAXParser parser = factory.newSAXParser();
			if (logger.isInfoEnabled()) {
				logger.info("Parsing XML....");
			}
			parser.parse(IOUtils.toInputStream(xml), this);
		} catch (ParserConfigurationException ex) {
			this.activeElement = null;
			logger.error("Error while parsing XML...", ex);
		} catch (SAXException ex) {
			this.activeElement = null;
			logger.error("Error while parsing XML...", ex);
		} catch (IOException ex) {
			this.activeElement = null;
			logger.error("Error while parsing XML...", ex);
		}
		return this.getRootElement();
	}

	private String replaceNameSpace(String uri, String localName) {
		String prefix = this.nameSpaceHandler.getPrefix(uri);
		return prefix + ":" + localName;
	}
}
