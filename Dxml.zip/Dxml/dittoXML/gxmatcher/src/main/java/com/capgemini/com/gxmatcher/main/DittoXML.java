package com.capgemini.com.gxmatcher.main;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.payload.PayloadPair;
import com.capgemini.com.gxmatcher.reader.PayloadInputReader;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;
import com.capgemini.com.gxmatcher.writer.ResultWriter;

public class DittoXML {

	final static Logger logger = Logger.getLogger(DittoXML.class);

	private PayloadInputReader inputReader;
	private ResultWriter writer;

	public DittoXML(PayloadInputReader inputReader, ResultWriter writer) {
		super();
		this.inputReader = inputReader;
		this.writer = writer;
	}

	public void start() {
		// Number of threads
		int numberOfProcessors = Runtime.getRuntime().availableProcessors();
		int numberofThreads = numberOfProcessors * 4;
		if (logger.isDebugEnabled()) {
			logger.debug("Using " + numberofThreads + " threads...");
		}

		// Initializing thread pool
		ExecutorService es = Executors.newFixedThreadPool(numberofThreads);

		// Processing input
		List<PayloadPair> payloadInputs = this.inputReader.generatePayloadInfos();
		try {
			for (PayloadPair info : payloadInputs) {
				GXRunner runner = new GXRunner(info);
				es.execute(runner);
			}
			// waiting for all threads to complete
			es.shutdown();
			boolean finished = es.awaitTermination(PropertiesUtil.getInstance().getTerminationWaitTime(),
					TimeUnit.MINUTES);

			// generating output
			if (finished) {
				this.writer.processResult(payloadInputs);
			} else {
				logger.warn("Took too long to process XMLS");
				logger.warn("**PROCESS TERMINATED**");
			}
		} catch (Exception e) {
			logger.error(e);
		}
	}

}
