package com.capgemini.com.gxmatcher.cleanser;

public abstract class GXCleanser {

	protected String cleansedXML;

	public abstract String cleanse(String xml);

	public String getCleansedXML() {
		return cleansedXML;
	}

}
