package com.capgemini.com.gxmatcher.writer;

import java.util.List;

import com.capgemini.com.gxmatcher.payload.PayloadPair;

public interface ResultWriter {

	public boolean processResult(List<PayloadPair> pairs);
}
