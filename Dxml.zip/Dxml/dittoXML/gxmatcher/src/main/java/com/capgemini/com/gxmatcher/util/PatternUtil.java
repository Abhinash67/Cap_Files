package com.capgemini.com.gxmatcher.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternUtil {
	
	public static String getXMLTagPattern(String xmlTag) {
		return "<(.*)(:?)"+xmlTag+">(.*)</(.*)(:?)"+xmlTag+">";
	}
	
	public static String getValue(String xml, String pattern) {
		String value = null;
		Pattern r= Pattern.compile(pattern);
		Matcher m = r.matcher(xml);
		if(m.find()) {
			value = m.group(3);
		}
		return value;
	}

}
