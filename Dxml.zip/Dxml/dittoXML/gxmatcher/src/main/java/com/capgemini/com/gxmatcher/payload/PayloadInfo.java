package com.capgemini.com.gxmatcher.payload;

public class PayloadInfo {
	
	private String accountNumber;
	private String policyNumber;
	private String customerName;
	private String serviceID;
	private String eventName;
	private String transactionID;
	private String payloadType;
	private String fileName;
	private String url;
	private String sortedXMLPath;

	public PayloadInfo(String accountNumber, String policyNumber, String customerName, String serviceID,
			String eventName, String transactionID, String payloadType, String fileName, String url) {
		super();
		this.accountNumber = accountNumber;
		this.policyNumber = policyNumber;
		this.customerName = customerName;
		this.serviceID = serviceID;
		this.eventName = eventName;
		this.transactionID = transactionID;
		this.payloadType = payloadType;
		this.fileName = fileName;
		this.url = url;
	}

	public String getAccountNumber() {
		return accountNumber;
	}

	public String getPolicyNumber() {
		return policyNumber;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getServiceID() {
		return serviceID;
	}

	public String getTransactionID() {
		return transactionID;
	}

	public String getPayloadType() {
		return payloadType;
	}

	public String getFileName() {
		return fileName;
	}

	public String getUrl() {
		return url;
	}

	public String getEventName() {
		return eventName;
	}
	
	public String getSortedXMLPath() {
		return sortedXMLPath;
	}

	public void setSortedXMLPath(String sortedXMLPath) {
		this.sortedXMLPath = sortedXMLPath;
	}

	@Override
	public String toString() {
		return "AccountNumber-> " + this.accountNumber + "|PolicyNumber-> " + this.policyNumber + "|CustomerName->"
				+this.customerName + "|EventName-> " + this.eventName + "|ServiceID->" + this.serviceID
				+"|TransactionID->" + this.transactionID + "|PayloadType->" + this.payloadType + "|FileName"
				+ this.fileName +"|Url->" + this.url;
	}
}
