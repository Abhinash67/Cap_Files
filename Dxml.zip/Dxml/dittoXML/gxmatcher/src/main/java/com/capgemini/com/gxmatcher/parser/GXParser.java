package com.capgemini.com.gxmatcher.parser;

public interface GXParser {

	public GXNode parseXML(String xml);

}
