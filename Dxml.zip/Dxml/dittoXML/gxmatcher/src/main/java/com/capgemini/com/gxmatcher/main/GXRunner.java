package com.capgemini.com.gxmatcher.main;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.constants.MessageDestination;
import com.capgemini.com.gxmatcher.payload.PayloadInfo;
import com.capgemini.com.gxmatcher.payload.PayloadPair;
import com.capgemini.com.gxmatcher.reader.GXInput;
import com.capgemini.com.gxmatcher.reader.impl.FileInput;
import com.capgemini.com.gxmatcher.reader.impl.WSInput;
import com.capgemini.com.gxmatcher.util.GXMatcherUtil;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;

public class GXRunner implements Runnable {

	final static Logger logger = Logger.getLogger(GXRunner.class);

	private GXInput input1;
	private GXInput input2;
	private GXMatcher matcher;
	private PayloadPair pair;

	private boolean result;

	public GXRunner(PayloadPair pair) {
		super();
		this.pair = pair;

		PayloadInfo payloadInfo1 = pair.getPayloadInfo1();
		if (!StringUtils.isEmpty(payloadInfo1.getUrl())) {
			this.input1 = new WSInput(pair.getPayloadInfo1());
		} else {
			this.input1 = new FileInput(payloadInfo1);
		}

		PayloadInfo payloadInfo2 = pair.getPayloadInfo2();
		if (!StringUtils.isEmpty(payloadInfo2.getUrl())) {
			this.input2 = new WSInput(pair.getPayloadInfo2());
		} else {
			this.input2 = new FileInput(payloadInfo2);
		}
	}

	public void start() {
		String filePath1 = generateFileName(input1.getFileName());
		String filePath2 = generateFileName(input2.getFileName());
		if (filePath1 != null && filePath2 != null) {
			this.matcher = new GXMatcher(MessageDestination.MD1, filePath1, filePath2);
			this.result = this.matcher.match();
			pair.setMatch(this.result);
			pair.getPayloadInfo1().setSortedXMLPath(this.matcher.getSortedXMLPath1());
			pair.getPayloadInfo2().setSortedXMLPath(this.matcher.getSortedXMLPath2());
		}
	}

	public boolean getResult() {
		return result;
	}

	private String generateFileName(String fileName) {
		if (!StringUtils.isBlank(fileName)) {
			if (fileName.contains("\\") || fileName.contains("/")) {
				return fileName;
			} else {
				return PropertiesUtil.getInstance().getXMLFilePath() + "/"+ fileName;
			}
		}
		return null;
	}

	@Override
	public void run() {
		this.start();
	}

}
