package com.capgemini.com.gxmatcher.validator;

public abstract class GXValidator {

	public abstract boolean validate(String xml);

}
