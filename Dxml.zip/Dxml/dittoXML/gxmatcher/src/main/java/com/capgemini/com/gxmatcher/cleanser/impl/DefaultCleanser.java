package com.capgemini.com.gxmatcher.cleanser.impl;

import java.io.StringWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.w3c.dom.Document;

import com.capgemini.com.gxmatcher.cleanser.GXCleanser;
import com.capgemini.com.gxmatcher.constants.CleansingPattern;
import com.capgemini.com.gxmatcher.constants.Constants;
import com.capgemini.com.gxmatcher.constants.ReplacePattern;
import com.capgemini.com.gxmatcher.util.PatternUtil;
import com.capgemini.com.gxmatcher.util.XMLUtil;

public class DefaultCleanser extends GXCleanser {

	final static Logger logger = Logger.getLogger(DefaultCleanser.class);

	public String cleanse(String xml) {
		if (logger.isInfoEnabled()) {
			logger.info("Cleansing XML....");
		}
		try {
			this.cleansedXML = xml;
			prettyPrint();
			removeStandardTags();
			replaceValues();
			replaceTime();
			removeEmptyLines();
		} catch (Exception ex) {
			this.cleansedXML = null;
			logger.error("Error while cleansing XML....", ex);
		}
		return this.cleansedXML;
	}

	private void removeStandardTags() {
		if (logger.isDebugEnabled()) {
			logger.debug("Removed standard tags from XML....");
		}
		for (CleansingPattern cleansingPattern : CleansingPattern.values()) {
			if (logger.isTraceEnabled()) {
				logger.trace("Removing TAG: " + cleansingPattern.name() + " from XML....");
			}
			this.cleansedXML = this.cleansedXML.replaceAll(cleansingPattern.getPattern(),
					cleansingPattern.getReplacementString());
		}
	}

	private void replaceValues() {
		if (logger.isDebugEnabled()) {
			logger.debug("Removing values from XML....");
		}
		for (ReplacePattern replacePattern : ReplacePattern.values()) {
			String value = PatternUtil.getValue(this.cleansedXML, replacePattern.getPattern());
			if (!StringUtils.isEmpty(value)) {
				String replacementValue = value.replaceAll(".", "0");
				if (logger.isTraceEnabled()) {
					logger.trace(
							"Replacing " + replacePattern.name() + " from XML....|" + value + "->" + replacementValue);
				}
				this.cleansedXML = this.cleansedXML.replaceAll(value, replacementValue);
			}
		}
	}

	private void replaceTime() {
		if (logger.isDebugEnabled()) {
			logger.debug("Removing timestamps from XML....");
		}
		Pattern r = Pattern.compile(Constants.TIME_PATTERN);
		Matcher m = r.matcher(this.cleansedXML);
		StringBuffer sb = new StringBuffer();
		while (m.find()) {
			m.appendReplacement(sb, m.group(0).replaceFirst(Pattern.quote(m.group(5)), ""));
		}
		m.appendTail(sb);
		this.cleansedXML = sb.toString();
	}

	private void removeEmptyLines() {
		if (logger.isDebugEnabled()) {
			logger.debug("Removing empty lines from XML....");
		}
		this.cleansedXML = this.cleansedXML.replaceAll(Constants.EMPTY_LINE_PATTERN, Constants.EMPTY_STRING);

	}

	private void prettyPrint() {
		if (logger.isDebugEnabled()) {
			logger.debug("Pretty Printing XML....");
		}
		this.cleansedXML = XMLUtil.prettyPrint(this.cleansedXML);
	}

}
