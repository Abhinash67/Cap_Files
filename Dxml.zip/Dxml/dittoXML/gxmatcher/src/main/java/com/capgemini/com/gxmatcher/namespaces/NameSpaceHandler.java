package com.capgemini.com.gxmatcher.namespaces;

import java.util.HashMap;
import java.util.Map;

public class NameSpaceHandler {

	private Map<String, String> namespaceMap = new HashMap<String, String>();

	private int counter = 0;

	public void addNameSpace(String uri) {
		if (namespaceMap.get(uri) == null) {
			String prefix = generatePrefix(uri);
			namespaceMap.put(uri, prefix);
		}
	}

	public String getPrefix(String uri) {
		return namespaceMap.get(uri);
	}

	private String generatePrefix(String uri) {
		this.counter++;
		return "ns" + this.counter;
	}
}
