package com.capgemini.com.gxmatcher.writer.impl;

import java.io.File;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.payload.PayloadPair;
import com.capgemini.com.gxmatcher.util.GXMatcherUtil;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;
import com.capgemini.com.gxmatcher.writer.ResultWriter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class JSONResultWriter implements ResultWriter {
	final static Logger logger = Logger.getLogger(JSONResultWriter.class);

	@Override
	public boolean processResult(List<PayloadPair> pairs) {
		boolean success = false;
		if (logger.isInfoEnabled()) {
			logger.info("Generating result...");
		}
		try {

			ObjectMapper mapper = new ObjectMapper();
			mapper.enable(SerializationFeature.INDENT_OUTPUT);

			String fileName = GXMatcherUtil.CONSTANT_TIMESTAMP + "_Result.json";
			String filePath = PropertiesUtil.getInstance().getResultFilePath() + "/" + fileName;
			File file = new File(filePath);
			file.getParentFile().mkdirs();
			mapper.writeValue(file, pairs);
			if (logger.isInfoEnabled()) {
				logger.info("Result generated at " + filePath);
			}
			success = true;
		} catch (Exception e) {
			logger.error("Error while generating result", e);
		}

		return success;
	}

}
