package com.capgemini.com.gxmatcher.main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;

import com.capgemini.com.gxmatcher.cleanser.GXCleanser;
import com.capgemini.com.gxmatcher.cleanser.impl.DefaultCleanser;
import com.capgemini.com.gxmatcher.constants.MessageDestination;
import com.capgemini.com.gxmatcher.module.GXModule;
import com.capgemini.com.gxmatcher.namespaces.NameSpaceHandler;
import com.capgemini.com.gxmatcher.parser.GXNode;
import com.capgemini.com.gxmatcher.parser.GXParser;
import com.capgemini.com.gxmatcher.parser.impl.GXSAXParser;
import com.capgemini.com.gxmatcher.reader.GXReader;
import com.capgemini.com.gxmatcher.reader.impl.FileReader;
import com.capgemini.com.gxmatcher.util.GXMatcherUtil;
import com.capgemini.com.gxmatcher.util.PropertiesUtil;

public class GXMatcher {

	final static Logger logger = Logger.getLogger(GXMatcher.class);
	private MessageDestination messageDestination;
	private String filePath1;
	private String filePath2;
	private String sortedXMLPath1;
	private String sortedXMLPath2;
	private NameSpaceHandler nameSpaceHandler;

	public GXMatcher(MessageDestination messageDestination, String filePath1, String filePath2) {
		super();
		if (logger.isInfoEnabled()) {
			logger.info("Initializing GX Matcher with MessageDestination" + messageDestination.name() + "....");
		}
		this.messageDestination = messageDestination;
		this.filePath1 = filePath1;
		this.filePath2 = filePath2;
		this.nameSpaceHandler = new NameSpaceHandler();
	}

	public boolean match() {
		boolean result = false;
		if (logger.isInfoEnabled()) {
			logger.info("XML 1: " + filePath1);
		}
		GXModule module1 = createGXModule(filePath1);
		String module1Checksum = module1.getChecksum();

		if (logger.isInfoEnabled()) {
			logger.info("XML 2: " + filePath2);
		}
		GXModule module2 = createGXModule(filePath2);
		String module2Checksum = module2.getChecksum();

		if ((!StringUtils.isBlank(module1Checksum)) && (!StringUtils.isBlank(module2Checksum))) {
			result = module1Checksum.equals(module2Checksum);
		}
		if (logger.isInfoEnabled()) {
			logger.info("XML match: " + result);
		}

		if (!result) {
			if (logger.isInfoEnabled()) {
				logger.info("XML mismatch -> Generating sorted xmls for manual comparison...");
			}
			handleMismatch(module1, module2);
		}
		return result;

	}
	
	public String getSortedXMLPath1() {
		return sortedXMLPath1;
	}

	public String getSortedXMLPath2() {
		return sortedXMLPath2;
	}

	private GXModule createGXModule(String filePath) {
		GXModule module = null;
		switch (messageDestination) {
		case MD1:
			GXReader reader = new FileReader(filePath);
			GXCleanser cleanser = new DefaultCleanser();
			GXParser parser = new GXSAXParser(this.nameSpaceHandler);
			module = new GXModule(messageDestination, reader, cleanser, parser);
			break;
		default:
		}
		return module;
	}

	private void handleMismatch(GXModule module1, GXModule module2) {
		String timeStamp = GXMatcherUtil.getTimeStamp();
		String filePath = PropertiesUtil.getInstance().getMismatchXMLFilePath()+"/"+GXMatcherUtil.CONSTANT_TIMESTAMP;
		this.sortedXMLPath1 = filePath + "/" + timeStamp + "__Sorted_" + getFileName(filePath1);
		this.sortedXMLPath2 = filePath + "/" + timeStamp + "__Sorted_" + getFileName(filePath2);
		//finds the missing node
		if (logger.isDebugEnabled()) {
			logger.info("XML mismatch -> Finding missing nodes...");
		}
		findMissingNodes(module1, module2);
		//writes the sorted XML to file
		if (logger.isDebugEnabled()) {
			logger.debug("XML mismatch -> Writing sorted XML 1...");
		}
		module1.writeFullSortedXML(this.sortedXMLPath1);
		if (logger.isDebugEnabled()) {
			logger.debug("XML mismatch -> Writing sorted XML 2...");
		}
		module2.writeFullSortedXML(this.sortedXMLPath2);
	}

	private String getFileName(String filePath) {
		String fileName = filePath.replace("/", "|").replace("\\", "|");
		return fileName.substring(fileName.lastIndexOf("|") + 1, fileName.length());
	}
	

	private void findMissingNodes(GXModule module1, GXModule module2) {
		Map<String, GXNode> map1 = module1.getReverseLookupMap();
		Map<String, GXNode> map2 = module2.getReverseLookupMap();
		
		//xml1 diff with xml2
		List<String> keys= new ArrayList<String>(map1.keySet());
		Collections.sort(keys, new KeyComparator());
		for(String key :keys) {
			GXNode node = map2.remove(key);
			if(node == null) {
				node = map1.get(key);
				if(node != null) {
					node.setMissingNode(true);
					cleanseMap(key, map1);
				}
			}
		}
		
		//xml2 diff with xml1
		keys= new ArrayList<String>(map2.keySet());
		Collections.sort(keys, new KeyComparator());
		for(String key :keys) {
			
			GXNode node = map2.get(key);
			if(node != null) {
				node.setMissingNode(true);
				cleanseMap(key, map2);
			}
		}
	}
	
	private void cleanseMap(String cleansekey, Map<String, GXNode> map) {
		List<String> keysToRemove = new ArrayList<String>();
		for(String key : map.keySet()) {
			if(key.startsWith(cleansekey)) {
				keysToRemove.add(key);
			}
		}
		if(!keysToRemove.isEmpty()) {
			for(String key : keysToRemove) {
				map.remove(key);
			}
		}
	}
	
	static class KeyComparator implements Comparator<String>
	 {
	     public int compare(String s1, String s2)
	     {
	    	 Integer s1Count = StringUtils.countMatches(s1, "\\");
	    	 Integer s2Count = StringUtils.countMatches(s2, "\\");
	         if(s1Count < s2Count) {
	        	 return -1;
	         } else if( s1Count > s2Count) {
	        	 return 1;
	         } else {
	        	 return 0;
	         }
	         
	     }
	 }
}
