package com.capgemini.com.gxmatcher.constants;

public class Constants {

	public static final String EMPTY_STRING = "";
	public static final String EMPTY_LINE_PATTERN = "(?m)^[ \t]*\r?\n";
	public static final String TIME_PATTERN = "<(.*)>([0-9]{4})-([0-9]{2})-([0-9]{2})T(.*)</(.*)>";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String REQUEST = "REQUEST";
	public static final String RESPONSE = "RESPONSE";
	public static final String MESSAGE = "MESSAGE";
	public static final String MISSING_NODE = "<!-- Missing Node -->";
}
